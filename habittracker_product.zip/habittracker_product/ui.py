from __future__ import annotations

import tkinter as tk
from datetime import date, timedelta
from tkinter import messagebox, ttk

from models import Habit
from services import HabitService


class HabitDialog(tk.Toplevel):
    def __init__(self, master: tk.Misc, service: HabitService, habit: Habit | None = None) -> None:
        super().__init__(master)
        self.service = service
        self.habit = habit
        self.result = False
        self.title("Добавление привычки" if habit is None else "Редактирование привычки")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()

        self.columnconfigure(1, weight=1)

        self.title_var = tk.StringVar(value=habit.title if habit else "")
        self.desc_var = tk.StringVar(value=habit.description if habit else "")
        self.schedule_var = tk.StringVar(value=habit.schedule_type if habit else "daily")
        self.target_var = tk.StringVar(value=str(habit.schedule_value) if habit else "1")
        self.start_var = tk.StringVar(value=habit.start_date if habit else date.today().isoformat())
        self.status_var = tk.StringVar(value=habit.status if habit else "active")

        fields = [
            ("Название:", ttk.Entry(self, textvariable=self.title_var, width=40)),
            ("Описание:", ttk.Entry(self, textvariable=self.desc_var, width=40)),
        ]
        for row_idx, (label, widget) in enumerate(fields):
            ttk.Label(self, text=label).grid(row=row_idx, column=0, padx=10, pady=6, sticky="w")
            widget.grid(row=row_idx, column=1, padx=10, pady=6, sticky="ew")

        ttk.Label(self, text="Тип:").grid(row=2, column=0, padx=10, pady=6, sticky="w")
        ttk.Combobox(
            self,
            textvariable=self.schedule_var,
            values=["daily", "weekly"],
            state="readonly",
            width=12,
        ).grid(row=2, column=1, padx=10, pady=6, sticky="w")

        ttk.Label(self, text="Цель:").grid(row=3, column=0, padx=10, pady=6, sticky="w")
        ttk.Entry(self, textvariable=self.target_var, width=10).grid(row=3, column=1, padx=10, pady=6, sticky="w")

        ttk.Label(self, text="Дата начала:").grid(row=4, column=0, padx=10, pady=6, sticky="w")
        ttk.Entry(self, textvariable=self.start_var, width=14).grid(row=4, column=1, padx=10, pady=6, sticky="w")

        ttk.Label(self, text="Статус:").grid(row=5, column=0, padx=10, pady=6, sticky="w")
        ttk.Combobox(
            self,
            textvariable=self.status_var,
            values=["active", "archived"],
            state="readonly",
            width=12,
        ).grid(row=5, column=1, padx=10, pady=6, sticky="w")

        button_row = ttk.Frame(self)
        button_row.grid(row=6, column=0, columnspan=2, padx=10, pady=10, sticky="e")
        ttk.Button(button_row, text="Сохранить", command=self.on_save).pack(side="left", padx=4)
        ttk.Button(button_row, text="Отмена", command=self.destroy).pack(side="left", padx=4)

    def on_save(self) -> None:
        try:
            target = int(self.target_var.get())
            if self.habit is None:
                self.service.create_habit(
                    self.title_var.get(),
                    self.desc_var.get(),
                    self.schedule_var.get(),
                    target,
                    self.start_var.get(),
                )
            else:
                self.service.update_habit(
                    self.habit.id,
                    self.title_var.get(),
                    self.desc_var.get(),
                    self.schedule_var.get(),
                    target,
                    self.start_var.get(),
                    self.status_var.get(),
                )
            self.result = True
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc), parent=self)


class HabitTrackerApp(tk.Tk):
    def __init__(self, service: HabitService) -> None:
        super().__init__()
        self.service = service
        self.selected_habit_id: int | None = None

        self.title("HabitTracker")
        self.geometry("1180x760")
        self.minsize(1020, 680)
        self.configure(bg="#f5f7fb")

        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Card.TFrame", background="#ffffff")
        style.configure("CardTitle.TLabel", background="#ffffff", font=("Segoe UI", 11, "bold"))
        style.configure("Muted.TLabel", background="#ffffff", foreground="#5b6475")
        style.configure("Accent.TButton", padding=(12, 8))

        self.filter_var = tk.StringVar(value="active")
        self.date_var = tk.StringVar(value=date.today().isoformat())
        self.period_var = tk.StringVar(value="week")

        self._build_layout()
        self.refresh_habits()

    def _build_layout(self) -> None:
        container = ttk.Frame(self, padding=18)
        container.pack(fill="both", expand=True)
        container.columnconfigure(0, weight=2)
        container.columnconfigure(1, weight=3)
        container.rowconfigure(1, weight=1)

        header = ttk.Frame(container)
        header.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 16))
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="HabitTracker", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Локальный трекер привычек на Python + Tkinter + SQLite",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Button(header, text="Добавить привычку", style="Accent.TButton", command=self.open_create).grid(row=0, column=1, rowspan=2, sticky="e")

        left_card = ttk.Frame(container, style="Card.TFrame", padding=14)
        left_card.grid(row=1, column=0, sticky="nsew", padx=(0, 12))
        left_card.rowconfigure(2, weight=1)
        left_card.columnconfigure(0, weight=1)

        controls = ttk.Frame(left_card)
        controls.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        controls.columnconfigure(1, weight=1)
        ttk.Label(controls, text="Список привычек", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Combobox(
            controls,
            textvariable=self.filter_var,
            values=["active", "archived", "all"],
            state="readonly",
            width=12,
        ).grid(row=0, column=1, sticky="e")
        self.filter_var.trace_add("write", lambda *_: self.refresh_habits())

        columns = ("title", "schedule", "start", "status")
        self.habit_tree = ttk.Treeview(left_card, columns=columns, show="headings", height=18)
        self.habit_tree.heading("title", text="Название")
        self.habit_tree.heading("schedule", text="Режим")
        self.habit_tree.heading("start", text="Старт")
        self.habit_tree.heading("status", text="Статус")
        self.habit_tree.column("title", width=220)
        self.habit_tree.column("schedule", width=120, anchor="center")
        self.habit_tree.column("start", width=100, anchor="center")
        self.habit_tree.column("status", width=90, anchor="center")
        self.habit_tree.grid(row=2, column=0, sticky="nsew")
        self.habit_tree.bind("<<TreeviewSelect>>", self.on_habit_selected)

        actions = ttk.Frame(left_card)
        actions.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        for text, command in [
            ("Обновить", self.refresh_habits),
            ("Редактировать", self.open_edit),
            ("Удалить", self.delete_selected),
        ]:
            ttk.Button(actions, text=text, command=command).pack(side="left", padx=(0, 6))

        right_area = ttk.Frame(container)
        right_area.grid(row=1, column=1, sticky="nsew")
        right_area.rowconfigure(1, weight=1)
        right_area.columnconfigure(0, weight=1)

        top_stats = ttk.Frame(right_area)
        top_stats.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        top_stats.columnconfigure((0, 1, 2), weight=1)
        self.summary_labels: dict[str, ttk.Label] = {}
        for idx, key in enumerate(["Выполнено", "Цель", "Процент"]):
            card = ttk.Frame(top_stats, style="Card.TFrame", padding=16)
            card.grid(row=0, column=idx, sticky="nsew", padx=(0 if idx == 0 else 8, 0))
            ttk.Label(card, text=key, style="Muted.TLabel").pack(anchor="w")
            lbl = ttk.Label(card, text="-", style="CardTitle.TLabel", font=("Segoe UI", 20, "bold"))
            lbl.pack(anchor="w", pady=(10, 0))
            self.summary_labels[key] = lbl

        notebook = ttk.Notebook(right_area)
        notebook.grid(row=1, column=0, sticky="nsew")

        self.tab_completion = ttk.Frame(notebook, padding=16)
        self.tab_completion.columnconfigure(0, weight=1)
        self.tab_completion.columnconfigure(1, weight=1)
        notebook.add(self.tab_completion, text="Отметка и описание")

        self.tab_stats = ttk.Frame(notebook, padding=16)
        self.tab_stats.columnconfigure(0, weight=1)
        notebook.add(self.tab_stats, text="Статистика")

        ttk.Label(self.tab_completion, text="Детали привычки", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.details_text = tk.Text(self.tab_completion, height=10, wrap="word", relief="flat", bg="#ffffff")
        self.details_text.grid(row=1, column=0, sticky="nsew", padx=(0, 12), pady=(8, 12))
        self.details_text.configure(state="disabled")

        action_card = ttk.Frame(self.tab_completion, style="Card.TFrame", padding=14)
        action_card.grid(row=1, column=1, sticky="nsew", pady=(8, 12))
        ttk.Label(action_card, text="Ежедневная фиксация", style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(action_card, text="Дата (ГГГГ-ММ-ДД):").pack(anchor="w", pady=(12, 4))
        ttk.Entry(action_card, textvariable=self.date_var, width=16).pack(anchor="w")
        self.done_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(action_card, text="Привычка выполнена", variable=self.done_var).pack(anchor="w", pady=10)
        ttk.Button(action_card, text="Сохранить отметку", command=self.save_mark).pack(anchor="w")
        ttk.Button(action_card, text="Сегодня", command=lambda: self.date_var.set(date.today().isoformat())).pack(anchor="w", pady=(8, 0))

        stat_controls = ttk.Frame(self.tab_stats)
        stat_controls.grid(row=0, column=0, sticky="ew")
        ttk.Label(stat_controls, text="Период:").pack(side="left")
        ttk.Combobox(stat_controls, textvariable=self.period_var, values=["week", "month"], state="readonly", width=10).pack(side="left", padx=6)
        ttk.Button(stat_controls, text="Показать", command=self.refresh_stats).pack(side="left")

        metric_frame = ttk.Frame(self.tab_stats, style="Card.TFrame", padding=16)
        metric_frame.grid(row=1, column=0, sticky="ew", pady=12)
        self.metric_label = ttk.Label(metric_frame, text="Выберите привычку", style="CardTitle.TLabel")
        self.metric_label.pack(anchor="w")
        self.streak_label = ttk.Label(metric_frame, text="")
        self.streak_label.pack(anchor="w", pady=(8, 0))

        ttk.Label(self.tab_stats, text="Календарь активности (последние 35 дней)", style="CardTitle.TLabel").grid(row=2, column=0, sticky="w")
        self.activity_text = tk.Text(self.tab_stats, height=12, wrap="none", relief="flat", bg="#ffffff")
        self.activity_text.grid(row=3, column=0, sticky="nsew", pady=(8, 0))
        self.activity_text.configure(state="disabled")

    def open_create(self) -> None:
        dialog = HabitDialog(self, self.service)
        self.wait_window(dialog)
        if dialog.result:
            self.refresh_habits()

    def open_edit(self) -> None:
        habit = self._require_selection()
        if not habit:
            return
        dialog = HabitDialog(self, self.service, habit)
        self.wait_window(dialog)
        if dialog.result:
            self.refresh_habits()
            self.show_habit_details(habit.id)

    def delete_selected(self) -> None:
        habit = self._require_selection()
        if not habit:
            return
        if messagebox.askyesno("Подтверждение", f"Удалить привычку '{habit.title}'?"):
            self.service.delete_habit(habit.id)
            self.selected_habit_id = None
            self.refresh_habits()
            self.clear_details()

    def refresh_habits(self) -> None:
        for item in self.habit_tree.get_children():
            self.habit_tree.delete(item)
        habits = self.service.list_habits(self.filter_var.get())
        for habit in habits:
            schedule = "Ежедневно" if habit.schedule_type == "daily" else f"{habit.schedule_value} раз/нед"
            self.habit_tree.insert("", "end", iid=str(habit.id), values=(habit.title, schedule, habit.start_date, habit.status))
        self.refresh_stats()

    def on_habit_selected(self, _event: object) -> None:
        selection = self.habit_tree.selection()
        if not selection:
            return
        habit_id = int(selection[0])
        self.selected_habit_id = habit_id
        self.show_habit_details(habit_id)
        self.refresh_stats()

    def show_habit_details(self, habit_id: int) -> None:
        habit = self.service.get_habit(habit_id)
        if not habit:
            return
        self.details_text.configure(state="normal")
        self.details_text.delete("1.0", "end")
        schedule = "ежедневно" if habit.schedule_type == "daily" else f"{habit.schedule_value} раз в неделю"
        text = (
            f"Название: {habit.title}\n"
            f"Описание: {habit.description or '—'}\n"
            f"Режим: {schedule}\n"
            f"Дата начала: {habit.start_date}\n"
            f"Статус: {habit.status}\n"
        )
        self.details_text.insert("1.0", text)
        self.details_text.configure(state="disabled")
        self.done_var.set(self.service.is_completed(habit_id, self.date_var.get()))

    def save_mark(self) -> None:
        habit = self._require_selection()
        if not habit:
            return
        try:
            self.service.toggle_completion(habit.id, self.date_var.get(), self.done_var.get())
            messagebox.showinfo("Готово", "Отметка сохранена.")
            self.refresh_stats()
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc))

    def refresh_stats(self) -> None:
        habit = self._get_selected_habit()
        if not habit:
            self.clear_stats()
            return
        today = date.today()
        if self.period_var.get() == "month":
            start = today.replace(day=1)
            if today.month == 12:
                next_month = date(today.year + 1, 1, 1)
            else:
                next_month = date(today.year, today.month + 1, 1)
            end = next_month - timedelta(days=1)
        else:
            start = today - timedelta(days=today.weekday())
            end = start + timedelta(days=6)
        stats = self.service.calculate_stats(habit.id, start.isoformat(), end.isoformat())
        self.summary_labels["Выполнено"].configure(text=str(stats.completed_count))
        self.summary_labels["Цель"].configure(text=str(stats.target_count))
        self.summary_labels["Процент"].configure(text=f"{stats.percent:.0f}%")
        self.metric_label.configure(text=f"Статистика по привычке: {habit.title}")
        self.streak_label.configure(text=f"Текущая серия: {stats.current_streak} | Максимальная серия: {stats.max_streak}")
        self._render_activity(habit.id)

    def _render_activity(self, habit_id: int) -> None:
        matrix = self.service.build_activity_matrix(habit_id, days=35)
        chunks = []
        for idx in range(0, len(matrix), 7):
            row = matrix[idx: idx + 7]
            cells = [f"{item[0][5:]} {'[X]' if item[1] else '[ ]'}" for item in row]
            chunks.append("  ".join(cells))
        text = "\n".join(chunks)
        self.activity_text.configure(state="normal")
        self.activity_text.delete("1.0", "end")
        self.activity_text.insert("1.0", text)
        self.activity_text.configure(state="disabled")

    def clear_details(self) -> None:
        self.details_text.configure(state="normal")
        self.details_text.delete("1.0", "end")
        self.details_text.configure(state="disabled")

    def clear_stats(self) -> None:
        for label in self.summary_labels.values():
            label.configure(text="-")
        self.metric_label.configure(text="Выберите привычку")
        self.streak_label.configure(text="")
        self.activity_text.configure(state="normal")
        self.activity_text.delete("1.0", "end")
        self.activity_text.configure(state="disabled")

    def _get_selected_habit(self) -> Habit | None:
        if self.selected_habit_id is None:
            return None
        return self.service.get_habit(self.selected_habit_id)

    def _require_selection(self) -> Habit | None:
        habit = self._get_selected_habit()
        if habit is None:
            messagebox.showwarning("Внимание", "Сначала выберите привычку из списка.")
            return None
        return habit
