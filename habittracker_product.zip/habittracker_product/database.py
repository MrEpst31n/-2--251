from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional


class DatabaseManager:
    def __init__(self, db_path: str | Path = "habittracker.db") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys = ON")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS habits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT DEFAULT '',
                    schedule_type TEXT NOT NULL DEFAULT 'daily',
                    schedule_value INTEGER NOT NULL DEFAULT 1,
                    start_date TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS habit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    habit_id INTEGER NOT NULL,
                    log_date TEXT NOT NULL,
                    status INTEGER NOT NULL DEFAULT 1,
                    comment TEXT DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE CASCADE,
                    UNIQUE(habit_id, log_date)
                );

                CREATE INDEX IF NOT EXISTS idx_habits_status ON habits(status);
                CREATE INDEX IF NOT EXISTS idx_logs_habit_date ON habit_logs(habit_id, log_date);
                """
            )

    def seed_demo_data(self) -> None:
        from datetime import date, timedelta

        with self.connect() as conn:
            count = conn.execute("SELECT COUNT(*) AS cnt FROM habits").fetchone()["cnt"]
            if count:
                return
            habits = [
                ("Выпивать 2 л воды", "Поддерживать питьевой режим", "daily", 1, date.today().isoformat(), "active"),
                ("Тренировка", "Минимум 3 тренировки в неделю", "weekly", 3, date.today().isoformat(), "active"),
                ("Чтение", "Читать не менее 20 минут", "daily", 1, date.today().isoformat(), "active"),
            ]
            conn.executemany(
                """
                INSERT INTO habits(title, description, schedule_type, schedule_value, start_date, status)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                habits,
            )
            habit_rows = conn.execute("SELECT id, schedule_type FROM habits ORDER BY id").fetchall()
            today = date.today()
            for row in habit_rows:
                for offset in range(0, 21):
                    current = today - timedelta(days=offset)
                    status = 1 if (row["id"] + offset) % 3 != 0 else 0
                    if row["schedule_type"] == "weekly":
                        status = 1 if offset % 2 == 0 else 0
                    if status:
                        conn.execute(
                            "INSERT OR IGNORE INTO habit_logs(habit_id, log_date, status) VALUES (?, ?, 1)",
                            (row["id"], current.isoformat()),
                        )
