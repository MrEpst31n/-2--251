from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class Habit:
    id: int
    title: str
    description: str
    schedule_type: str
    schedule_value: int
    start_date: str
    status: str


@dataclass(slots=True)
class HabitStats:
    completed_count: int
    target_count: int
    percent: float
    current_streak: int
    max_streak: int
