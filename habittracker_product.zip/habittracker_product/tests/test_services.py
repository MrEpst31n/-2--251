from __future__ import annotations

import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from database import DatabaseManager
from services import HabitService


class HabitServiceTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db = DatabaseManager(Path(self.tmpdir.name) / "test.db")
        self.service = HabitService(self.db)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_daily_stats_and_streaks(self) -> None:
        habit_id = self.service.create_habit("Чтение", "", "daily", 1, "2026-04-01")
        for dt in ["2026-04-01", "2026-04-02", "2026-04-03", "2026-04-05"]:
            self.service.toggle_completion(habit_id, dt, True)
        stats = self.service.calculate_stats(habit_id, "2026-04-01", "2026-04-07", today="2026-04-05")
        self.assertEqual(stats.completed_count, 4)
        self.assertEqual(stats.target_count, 7)
        self.assertAlmostEqual(stats.percent, 57.14, places=2)
        self.assertEqual(stats.current_streak, 1)
        self.assertEqual(stats.max_streak, 3)

    def test_weekly_streaks(self) -> None:
        habit_id = self.service.create_habit("Тренировки", "", "weekly", 2, "2026-04-01")
        entries = [
            "2026-04-01", "2026-04-03",  # week 14 enough
            "2026-04-08", "2026-04-10",  # week 15 enough
            "2026-04-16", "2026-04-18",  # week 16 enough
        ]
        for dt in entries:
            self.service.toggle_completion(habit_id, dt, True)
        stats = self.service.calculate_stats(habit_id, "2026-04-01", "2026-04-30", today="2026-04-18")
        self.assertEqual(stats.current_streak, 3)
        self.assertEqual(stats.max_streak, 3)

    def test_toggle_completion_remove(self) -> None:
        habit_id = self.service.create_habit("Вода", "", "daily", 1, "2026-04-01")
        self.service.toggle_completion(habit_id, "2026-04-01", True)
        self.assertTrue(self.service.is_completed(habit_id, "2026-04-01"))
        self.service.toggle_completion(habit_id, "2026-04-01", False)
        self.assertFalse(self.service.is_completed(habit_id, "2026-04-01"))


if __name__ == "__main__":
    unittest.main()
